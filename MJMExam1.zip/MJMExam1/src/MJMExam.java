/* EXAM1 - Simple Interest Generator.  This program uses the JTable for display of the year's generated
 * along with the simple interest calculation for up to 30 years.  
 */


import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.CardLayout;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.event.*;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;



@SuppressWarnings("serial")
public class MJMExam extends JFrame
{
	
	private JFrame frame;
	private JTextField txtFldPrincipal;
	private JTextField txtFldRate;
	private JTextField txtFldTime;
	private JTable table;
	private DefaultTableModel model;
	private JScrollPane scrollPaneInterest;
	
	
	int firstPass = 1;
	double numPrincipal;;
	double numRate;
	int numTime;
	double interestCalc;
	String [] headers = {"Year", "Interest Earned"};
	Object[][] data;
	String [] interestArray = new String[30];
	String [] cl = new String[30];
	String [] ii = new String[30];
	String [] iy = new String[30];
	int loadCntr;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MJMExam window = new MJMExam();
					window.frame.setVisible(true);
				} catch (Exception e) {
					//e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MJMExam() 
	{
		
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() 
	{
		frame = new JFrame();
		frame.setBounds(100, 100, 694, 616);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new CardLayout(0, 0));
		
		// Create new object class from external class Interest and
		// Establish Constructor by passing variables
		
					Interest intObj = new Interest(numPrincipal, numRate, numTime);
						 
// DECLARE JPANELS FOR GUI
				
		JPanel panelMain = new JPanel();
		panelMain.setForeground(new Color(0, 0, 102));
		panelMain.setBackground(new Color(255, 255, 204));
		frame.getContentPane().add(panelMain, "name_1042812826759786");
		panelMain.setLayout(null);
		
		JPanel panelDisplay = new JPanel();
		panelDisplay.setForeground(new Color(0, 0, 153));
		panelDisplay.setBackground(new Color(255, 255, 204));
		frame.getContentPane().add(panelDisplay, "name_1299680738766054");
		panelDisplay.setLayout(null);
		
// WINDOW MAIN DEFINITION
		
		JLabel lblHdgM = new JLabel("Simple Interest Calculator");
		lblHdgM.setForeground(new Color(0, 0, 153));
		lblHdgM.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblHdgM.setBounds(203, 85, 274, 20);
		panelMain.add(lblHdgM);
		
		JLabel lblRequest = new JLabel("Please enter the following information:");
		lblRequest.setForeground(new Color(0, 0, 153));
		lblRequest.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblRequest.setBounds(33, 159, 367, 20);
		panelMain.add(lblRequest);
		
		JLabel lblPrincipalM = new JLabel("Principal:");
		lblPrincipalM.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblPrincipalM.setForeground(new Color(0, 0, 153));
		lblPrincipalM.setBounds(261, 220, 83, 20);
		panelMain.add(lblPrincipalM);
		
		JLabel lblRateM = new JLabel("Rate (decimal format):");
		lblRateM.setForeground(new Color(0, 0, 153));
		lblRateM.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblRateM.setBounds(151, 268, 187, 20);
		panelMain.add(lblRateM);
		
		JLabel lblTime = new JLabel("Time (between 1-30):");
		lblTime.setForeground(new Color(0, 0, 153));
		lblTime.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblTime.setBounds(158, 307, 180, 20);
		panelMain.add(lblTime);
		
		JLabel lblErrMsgM = new JLabel(" ");
		lblErrMsgM.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblErrMsgM.setForeground(new Color(255, 0, 0));
		lblErrMsgM.setBounds(33, 439, 605, 20);
		panelMain.add(lblErrMsgM);
		
		txtFldPrincipal = new JTextField();
		txtFldPrincipal.setForeground(new Color(0, 0, 153));
		txtFldPrincipal.setFont(new Font("Tahoma", Font.BOLD, 16));
		txtFldPrincipal.setBounds(361, 217, 146, 26);
		panelMain.add(txtFldPrincipal);
		txtFldPrincipal.setColumns(10);
		
		txtFldRate = new JTextField();
		txtFldRate.setForeground(new Color(0, 0, 153));
		txtFldRate.setFont(new Font("Tahoma", Font.BOLD, 16));
		txtFldRate.setBounds(361, 262, 146, 26);
		panelMain.add(txtFldRate);
		txtFldRate.setColumns(10);
		
		txtFldTime = new JTextField();
		txtFldTime.setForeground(new Color(0, 0, 153));
		txtFldTime.setFont(new Font("Tahoma", Font.BOLD, 16));
		txtFldTime.setBounds(361, 304, 146, 26);
		panelMain.add(txtFldTime);
		txtFldTime.setColumns(10);
		
		// CREATE SECOND WINDOW/JTABLE
		// ****************CODE ADDED TO CREATE A TABLEMODEL TO LOAD JTABLE *******************
		
		// This class states the type of field being displayed and aligns them in the
		// table.  Integers - right aligned and Strings left aligned.  In this case I
		// am displaying tables that have been defined as strings so will not work.
		
		final Class[] columnClass = new Class[]
		{
				// Integer.class, Integer.class
				String.class, String.class
		};
		
		// Create the TableModel and add the data to it 
		DefaultTableModel model = new DefaultTableModel(data, headers);
		
		// Add the TableModelListener to the TableModel
		model.addTableModelListener(table);
		
		JTable table = new JTable(model)
		{
			
			@Override
			public boolean isCellEditable(int row, int column)
			{
		    	return false;
			}
				
			@Override
			public Class<?> getColumnClass(int columnIndex)
			{
				return columnClass[columnIndex];
			}
			
	    }; 
	    
	    JScrollPane scrollPaneInterest = new JScrollPane(table);
	    
	    							
		//scrollPaneInterest.setBounds(189, 139, 297, 324);
		scrollPaneInterest.setBounds(189, 139, 297, 200);
		panelDisplay.add(scrollPaneInterest);
		
		scrollPaneInterest.setViewportView(table);
		
		
		// THIS IS WHERE THE LOGIC OF THE MAIN WINDOW IS LOCATED
		JButton btnCalculate = new JButton("Calculate");
		btnCalculate.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnCalculate.setBackground(new Color(51, 102, 0));
		btnCalculate.setForeground(new Color(255, 255, 255));
		btnCalculate.setBounds(114, 364, 115, 29);
		panelMain.add(btnCalculate);
		btnCalculate.addActionListener(new ActionListener() 
		{
			
			/* This section controls the program flow.  Input field testing is performed here.
			   It the input passes validation methods are called from Interest.java that (1) set
			   the variables, (2) load an array to accumulate interest with a while loop for the
			   number of years (time) and (3) load an array with the time (years).  These arrays 
			   are then fed into an object array that will load the JTable for display in a 
			   scrolling table. 
			   
			   The edits made on the input fields are (1) all fields must be numeric (3) principal
			   and interest must both be greater than 0 and (3) time must be greater than or equal to 
			   1.
			   
			   There are 3 buttons on the initial panel ( Calculate, Clear and Quit).  On the JTable
			   panel there is a Quit button.
			   
			   NOTE:  Interestingly, through testing I found that if you enter an "f" or a "d" behind
			   a text number that is to be converted using Double.parseDouble the entry will be accepted.
			   This goes for the Principal and the Rate entries.  The calculation is not affected.
			   It will not accept an "f" or a "d" by itself.
			   
			*/
			 
			
			public void actionPerformed(ActionEvent arg0) 
			{
				try
				{
										
					numPrincipal = Double.parseDouble(txtFldPrincipal.getText());
					numRate = Double.parseDouble(txtFldRate.getText());
					numTime = Integer.parseInt(txtFldTime.getText());
					
					if ((numPrincipal > 0) && (numRate > 0))
					{	
						if (numTime >= 1)
						{	
							intObj.setVar(numPrincipal, numRate, numTime);
						
							// Calculated interest for the time entered is returned
							interestCalc = intObj.getInterest(numPrincipal, numRate, numTime);
							
							//Load Array to print the Accumulated Interest by Year in the JTable
							interestArray = intObj.getInterestLoad(numPrincipal, numRate, numTime);
							
							//Load Array to print the Year in the JTable
							cl = intObj.getCount(numTime);
							
							// Load Object Array with the interest Array for JTable data 
							Object[][] data = 
							{

									{cl[0], interestArray[0]},{cl[1], interestArray[1]}, {cl[2], interestArray[2]},
									{cl[3], interestArray[3]}, {cl[4], interestArray[4]}, {cl[5], interestArray[5]},
									{cl[6], interestArray[6]}, {cl[7], interestArray[7]}, {cl[8], interestArray[8]},
									{cl[9], interestArray[9]}, {cl[10], interestArray[10]}, {cl[11], interestArray[11]},
									{cl[12], interestArray[12]}, {cl[13], interestArray[13]}, {cl[14], interestArray[14]},
									{cl[15], interestArray[15]}, {cl[16], interestArray[16]}, {cl[17], interestArray[17]},
									{cl[18], interestArray[18]}, {cl[19], interestArray[19]}, {cl[20], interestArray[20]},
									{cl[21], interestArray[21]}, {cl[22], interestArray[22]}, {cl[23], interestArray[23]},
									{cl[24], interestArray[24]}, {cl[25], interestArray[25]}, {cl[26], interestArray[26]},
									{cl[27], interestArray[27]}, {cl[28], interestArray[28]}, {cl[29], interestArray[29]}
							};
							
							
							// This is the statement that reloads the JTable
							model.setDataVector(data, headers);
							
							
							lblErrMsgM.setText(null);
							panelMain.setVisible(false);
							panelDisplay.setVisible(true);
						}
						else
						{
							// All display fields except the user input field
							lblErrMsgM.setText("Time must be an integer greater than 0");
							panelMain.setVisible(true);
							txtFldTime.requestFocusInWindow();
							txtFldTime.setCaretPosition(0);
						}
						 
					}     
					else
					{	
						// All display fields except the user input fields
						lblErrMsgM.setText("Principal and Rate must be greater than 0");
						panelMain.setVisible(true);
						txtFldPrincipal.requestFocusInWindow();
						txtFldPrincipal.setCaretPosition(0);
					} 
				}
			    catch(NumberFormatException e1)
				{
			    	// All display fields except the user input fields
			    	lblErrMsgM.setText("Principal, Rate and Time must be numeric values");
			    	panelMain.setVisible(true);
					txtFldPrincipal.requestFocusInWindow();
					txtFldPrincipal.setCaretPosition(0);
				}
			
				
			}
		});
		
				
		JButton btnQuit = new JButton("Quit");
		btnQuit.setForeground(Color.WHITE);
		btnQuit.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnQuit.setBackground(new Color(255, 0, 0));
		btnQuit.setBounds(429, 364, 115, 29);
		panelMain.add(btnQuit);
		btnQuit.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				 
				lblErrMsgM.setText(null);
				txtFldPrincipal.setText(null);
				txtFldRate.setText(null);
				txtFldTime.setText(null);
				clrArrays();
				panelMain.setVisible(false);
				panelDisplay.setVisible(false);
				System.exit(0);
			}
		});
		
		JButton btnClear = new JButton("Clear Table");
		btnClear.setForeground(Color.WHITE);
		btnClear.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnClear.setBackground(new Color(51, 102, 0));
		btnClear.setBounds(261, 364, 129, 29);
		panelMain.add(btnClear);
		btnClear.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				lblErrMsgM.setText(null);
				txtFldPrincipal.setText(null);
				txtFldRate.setText(null);
				txtFldTime.setText(null);
				numPrincipal = 0;
				numRate = 0;
				numTime = 0;
				interestCalc = 0;
				clrArrays();
				panelMain.setVisible(true);
				txtFldPrincipal.requestFocusInWindow();
				txtFldPrincipal.setCaretPosition(0);
				
			}
		});
		
// DEFINE DISPLAY WINDOW WITH THE JTABLE AND JSCROLLPANE
				
		JLabel lblHdgD = new JLabel("Simple Interest Calculator");
		lblHdgD.setForeground(new Color(0, 0, 153));
		lblHdgD.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblHdgD.setBounds(203, 85, 274, 20);
		panelDisplay.add(lblHdgD);
		
		JLabel lblErrMsgD = new JLabel(" ");
		lblErrMsgD.setBackground(new Color(255, 255, 204));
		lblErrMsgD.setForeground(Color.RED);
		lblErrMsgD.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblErrMsgD.setBounds(15, 478, 642, 20);
		panelDisplay.add(lblErrMsgD);
			
		JButton btnReturn = new JButton("Return");
		btnReturn.setForeground(new Color(255, 255, 255));
		btnReturn.setBackground(new Color(255, 0, 0));
		btnReturn.setBounds(496, 410, 115, 29);
		panelDisplay.add(btnReturn);
		btnReturn.addActionListener(new ActionListener() 
		{
			
			public void actionPerformed(ActionEvent e) 
			{
				lblErrMsgD.setText(null);
				lblErrMsgM.setText(null);
				clrArrays();
				txtFldPrincipal.setText(null);
				txtFldRate.setText(null);
				txtFldTime.setText(null);
				panelDisplay.setVisible(false);
				panelMain.setVisible(true);
				 
				/*
				lblErrMsgD.setText(null);
				clrArrays();
				panelMain.setVisible(false);
				panelDisplay.setVisible(false);
				System.exit(0);
				*/		  
			}
		});
		
		
	// END OF INITIALIZE METHOD	
	}
	
	// CLEAR ARRAYS THAT LOAD DATA TO JTABLE
	public void clrArrays()
	{
		for (int x = 0; x < 30; x++)
		{
			cl[x] = null;
			interestArray[x] = null;
		}
	// END OF clrArrays Method	
	}

	
	
	// END OF CLASS		
}

