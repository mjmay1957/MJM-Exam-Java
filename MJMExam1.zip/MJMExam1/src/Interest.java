import java.text.DecimalFormat;

// This class contains the code to calculate interest.

public class Interest 
{
		static double principal;
		static double interest;
		static double rate;
		static int time;
		static double interestAccum = 0;
		static int arrayCntr = 0;
		static String accumStr;
		static String [] intDisplay = new String[30];
		static String [] cntrStr = new String[30];
		
	
	// CONSTRUCTOR
	
		public Interest(double p, double r, int t) 
		{  
		// ASSIGN PASSED PARAMETERS TO INITIALIZE VARIABLES IN THE CONSTRUCTOR
			principal = p;
			rate = r;
			time = t;
			
		// END OF CONSTRUCTOR ranNum
		}	
		
		
		// SET VARIABLES SECTION - INPUT BY USER
		public void setVar(double p, double r, int t
)
		{
			principal = p;
			rate = r;
			time = t;

		}

		
		// APPROPRIATE SETS
		
		// Principal Set
		public void setPrincipal (double p)
		{
			principal = p;
		}

		// Rate Set
		public void setRate (double r)
		{
			rate = r;
		}


		// Time Set
		public void setTime (int t)
		{
			time = t;
		}

		
		
		
		// APPROPRIATE GETS
		
		// Return Time to main
		public int getTime()
		{
			return time;
		}
		
		// Return Principal to main
		public double getPrincipal()
		{
			return principal;
		}
		
		// Return Rate to main
		public double getRate()
		{
			return rate;
		}		
		
			
		
		// CALCULATION SECTION OF THE OBJECT
		
		/* The Method getInterest will calculate simple interest from 3 arguments entered by the user.
		 * The calculation is Interest = Principal * Rate * Time 
		*/
		public static double getInterest(double p, double r, int t)
		{ 
			interest = principal * rate * time;  			 
								
		return interest;
		// END getInterest	
		}

		
		// getInterestLoad Method will load an array so that it can be displayed in a JTable in the GUI
		// Window
		public static String[] getInterestLoad(double p, double r, int t)
		{  
			interestAccum = 0;
			int c = 0;
			interest = principal * rate; // interest for 1 year 
			
			while (c < time)
			{
					DecimalFormat df = new DecimalFormat("$#,###,##0.00");
					interestAccum = interest + interestAccum;
					accumStr = df.format(interestAccum);
					intDisplay[c] = accumStr;
					
					c = c + 1;
			}
			// END FOR LOOP getInterest
	
		return intDisplay;
		// END getInterestLoad	
		}
		
		
		//Load Array to print the Year for each year that is calculated
		public static String[] getCount(int t)
		{  
			arrayCntr = 1;
			int j = 0;
			while (j < time)
			{
				cntrStr[j] = Integer.toString(arrayCntr);
				arrayCntr = arrayCntr + 1;
				j = j + 1;
			}
		return cntrStr;
		// END getCount
		}
		
// END OF CLASS Interest
}
		
		

		

		
		
			

 
